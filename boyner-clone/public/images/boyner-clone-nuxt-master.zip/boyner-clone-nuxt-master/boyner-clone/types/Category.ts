export interface ICategory {
  id?: string;
  name: string; // Örn: 'KADIN', 'ERKEK'
  slug: string; // Örn: 'kadin', 'erkek'
}